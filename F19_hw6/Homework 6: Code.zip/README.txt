To run various parts of the assignments please follow the below instructions.
running LQR:
python main.py --algo lqr

runnning iLQR:
python main.py --algo ilqr
